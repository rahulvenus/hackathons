

public class Connect4FieldModel {

	public void startTheGame(Connect4Field aConnect4Field) {
		
		aConnect4Field.playTheGame();
	}
}